document.addEventListener('DOMContentLoaded', (event) => {
    const form = document.getElementById('resumeForm');
    const addExperienceButton = document.getElementById('addExperience');
    const dynamicFields = document.getElementById('dynamicFields');

    // Function to add new work experience fields
    addExperienceButton.addEventListener('click', () => {
        const newField = document.createElement('div');
        newField.className = 'form-group';
        newField.innerHTML = `
            <label for="workExperience">Work Experience:</label>
            <input type="text" name="workExperience" required>
        `;
        dynamicFields.appendChild(newField);
    });

    // Form validation
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        let isValid = true;
        const inputs = form.querySelectorAll('input');
        inputs.forEach(input => {
            if (!input.checkValidity()) {
                isValid = false;
                input.classList.add('error');
            } else {
                input.classList.remove('error');
            }
        });

        if (isValid) {
            alert('Form submitted successfully!');
            form.submit();
        } else {
            alert('Please fill out all required fields.');
        }
    });
});